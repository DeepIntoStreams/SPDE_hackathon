import json
import math
import os
import os.path as osp
import sys
from copy import deepcopy

import hydra
import numpy as np
import scipy.io
import torch
from omegaconf import DictConfig, OmegaConf

current_directory = os.path.dirname(os.path.abspath(__file__))
new_data_root = osp.abspath(osp.join(current_directory, ".."))
if new_data_root not in sys.path:
    sys.path.insert(0, new_data_root)

from src.NoiseND import NoiseND
from src.SPDEs3D import SPDE3D


def build_initial_conditions(num, grid, fix_u0):
    if fix_u0:
        print("u0 is fixed!")
        return np.zeros((num, len(grid), len(grid), len(grid)), dtype=np.float32)

    noise = NoiseND()
    ic = 0.1 * noise.initial(num, (grid, grid, grid), scaling=1)
    ic = ic - ic[:, :1, :1, :1]
    print("u0 is varying!")
    return ic.astype(np.float32)


def single_path_tcxyz(batch_path, index=0):
    return np.expand_dims(batch_path[index], axis=1)


def build_save_dict(x, y, z, t, w, sol, spde, pre, save_single_path_tcxyz):
    mdict = {
        "X": np.asarray(x, dtype=np.float64),
        "Y": np.asarray(y, dtype=np.float64),
        "Z": np.asarray(z, dtype=np.float64),
        "T": np.asarray(t, dtype=np.float64),
        "W": np.asarray(w, dtype=np.float32),
        "sol": np.asarray(sol, dtype=np.float32),
        "N": np.array(spde.N, dtype=np.int32),
        "dt": np.array(spde.dt, dtype=np.float64),
        "eps": np.array(spde.eps, dtype=np.float64),
        "Cmass": np.array(pre.Cmass, dtype=np.float64),
    }
    if save_single_path_tcxyz:
        mdict["W_single_tcxyz"] = single_path_tcxyz(w).astype(np.float32)
        mdict["sol_single_tcxyz"] = single_path_tcxyz(sol).astype(np.float32)
    return mdict


def create_spde(N, dt, steps, num_tau, tau_max_multiplier, include_c12, seed=0):
    spde = SPDE3D(
        N=N,
        dt=dt,
        steps=steps,
        seed=seed,
        num_tau=num_tau,
        tau_max_multiplier=tau_max_multiplier,
        include_c12=include_c12,
    )
    pre = spde.precompute()
    return spde, pre


def simulate_shard(spde, pre, num, fix_u0, sample_start, base_seed):
    grid = spde.spatial_grid()
    time = spde.time_grid()
    initial_conditions = build_initial_conditions(num=num, grid=grid, fix_u0=fix_u0)

    w = np.zeros((num, spde.steps + 1, spde.M, spde.M, spde.M), dtype=np.float32)
    sol = np.zeros_like(w)

    for local_index in range(num):
        global_index = sample_start + local_index
        generator = torch.Generator(device=spde.device)
        generator.manual_seed(int(base_seed) + int(global_index))
        phi0 = initial_conditions[local_index]
        _, trajectory, noise = spde.rollout(phi0=phi0, pre=pre, generator=generator)

        noise_np = noise.detach().cpu().numpy().astype(np.float32)
        sol[local_index] = trajectory.detach().cpu().numpy().astype(np.float32)
        w[local_index, 1:] = np.cumsum(noise_np, axis=0, dtype=np.float32)

    return grid, grid, grid, time, w, sol


def shard_filename(save_name, fix_u0, N, steps, shard_num, sample_start, sample_end):
    ic_type = "xi" if fix_u0 else "u0_xi"
    return (
        f"{save_name}_{ic_type}_N{N}_steps{steps}_"
        f"shard{shard_num:04d}_samples{sample_start:06d}-{sample_end - 1:06d}.mat"
    )


def write_manifest(manifest_path, manifest):
    with open(manifest_path, "w", encoding="utf-8") as handle:
        json.dump(manifest, handle, indent=2)
    print("Saved manifest to", manifest_path)


@hydra.main(version_base=None, config_path="../configs/", config_name="phi43")
def main(cfg: DictConfig):
    total_num = int(cfg.get("total_num", cfg.sim.num))
    shard_size = int(cfg.get("shard_size", cfg.sim.num))
    start_shard = int(cfg.get("start_shard", 0))
    max_shards = cfg.get("max_shards", None)
    max_shards = None if max_shards is None else int(max_shards)
    skip_existing = bool(cfg.get("skip_existing", True))

    if total_num <= 0:
        raise ValueError("total_num must be positive.")
    if shard_size <= 0:
        raise ValueError("shard_size must be positive.")

    num_shards_total = int(math.ceil(total_num / shard_size))
    end_shard = num_shards_total if max_shards is None else min(num_shards_total, start_shard + max_shards)

    os.makedirs(cfg.save_dir, exist_ok=True)
    np.random.seed(int(cfg.seed))
    torch.manual_seed(int(cfg.seed))

    sim_cfg = OmegaConf.to_container(cfg.sim, resolve=True)
    sim_cfg = deepcopy(sim_cfg)
    sim_cfg.pop("num", None)
    spde, pre = create_spde(seed=cfg.seed, **sim_cfg)

    manifest = {
        "save_name": str(cfg.save_name),
        "save_dir": str(cfg.save_dir),
        "total_num": total_num,
        "shard_size": shard_size,
        "num_shards_total": num_shards_total,
        "seed": int(cfg.seed),
        "sim": OmegaConf.to_container(cfg.sim, resolve=True),
        "shards": [],
    }

    for shard_num in range(start_shard, end_shard):
        sample_start = shard_num * shard_size
        sample_end = min(total_num, sample_start + shard_size)
        shard_num_samples = sample_end - sample_start

        shard_dir = osp.join(cfg.save_dir, f"shard_{shard_num:04d}")
        os.makedirs(shard_dir, exist_ok=True)
        filename = shard_filename(
            save_name=cfg.save_name,
            fix_u0=cfg.sim.fix_u0,
            N=cfg.sim.N,
            steps=cfg.sim.steps,
            shard_num=shard_num,
            sample_start=sample_start,
            sample_end=sample_end,
        )
        save_path = osp.join(shard_dir, filename)

        if skip_existing and osp.exists(save_path):
            print(f"[shard {shard_num:04d}] exists, skipping: {save_path}")
            manifest["shards"].append({
                "shard": shard_num,
                "sample_start": sample_start,
                "sample_end": sample_end,
                "num": shard_num_samples,
                "path": save_path,
                "skipped": True,
            })
            continue

        print(
            f"[shard {shard_num:04d}/{num_shards_total - 1:04d}] "
            f"samples {sample_start}:{sample_end} ({shard_num_samples})"
        )
        np.random.seed(int(cfg.seed) + sample_start)
        torch.manual_seed(int(cfg.seed) + sample_start)
        x, y, z, t, w, sol = simulate_shard(
            spde=spde,
            pre=pre,
            num=shard_num_samples,
            fix_u0=cfg.sim.fix_u0,
            sample_start=sample_start,
            base_seed=cfg.seed,
        )

        mdict = build_save_dict(
            x=x,
            y=y,
            z=z,
            t=t,
            w=w,
            sol=sol,
            spde=spde,
            pre=pre,
            save_single_path_tcxyz=cfg.save_single_path_tcxyz,
        )
        scipy.io.savemat(save_path, mdict=mdict)
        print("Saved shard to", save_path)
        print("W shape:", w.shape)
        print("sol shape:", sol.shape)

        manifest["shards"].append({
            "shard": shard_num,
            "sample_start": sample_start,
            "sample_end": sample_end,
            "num": shard_num_samples,
            "path": save_path,
            "skipped": False,
        })

    manifest_path = osp.join(cfg.save_dir, "Phi43_shards_manifest.json")
    write_manifest(manifest_path, manifest)


if __name__ == "__main__":
    main()
